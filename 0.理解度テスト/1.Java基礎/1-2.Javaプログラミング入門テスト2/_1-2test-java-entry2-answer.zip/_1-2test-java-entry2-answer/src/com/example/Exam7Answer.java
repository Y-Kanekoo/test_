package com.example;

public class Exam7Answer {

	public static void main(String[] args) {

		String name = "伊賀将之";

		int i = 1;
		while (i <= 10) {
			System.out.println(i + "." + name);
			i++;
		}

	}

}