package com.example;

public class Exam6Answer {

	public static void main(String[] args) {

		int totalScore = -1;

		if (0 <= totalScore && totalScore < 80) {
			System.out.println("追試です");
		} else if (80 <= totalScore && totalScore < 100) {
			System.out.println("合格です");
		} else if (totalScore == 100) {
			System.out.println("満点です");
		} else {
			System.out.println("存在しない点数です");
		}

	}

}