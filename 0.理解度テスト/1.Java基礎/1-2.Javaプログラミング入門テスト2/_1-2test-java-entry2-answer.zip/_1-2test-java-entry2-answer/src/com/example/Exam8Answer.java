package com.example;

public class Exam8Answer {

	public static void main(String[] args) {

		int answer = 0;
		for (int i = 1; i <= 10; i++) {
			answer += i;
		}
		System.out.println(answer);

	}

}