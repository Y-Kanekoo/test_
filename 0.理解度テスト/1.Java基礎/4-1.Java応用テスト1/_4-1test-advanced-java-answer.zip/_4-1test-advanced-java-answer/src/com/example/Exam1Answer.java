package com.example;

public class Exam1Answer {
	public static void main(String[] args) {
		String name = "いがまさゆき";
		System.out.println(name + "の文字数は" + name.length() + "です。");
	}
}
