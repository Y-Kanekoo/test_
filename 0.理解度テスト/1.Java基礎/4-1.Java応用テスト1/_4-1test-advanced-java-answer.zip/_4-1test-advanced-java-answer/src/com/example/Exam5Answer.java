package com.example;

import java.time.LocalDate;

public class Exam5Answer {

	public static void main(String[] args) {
		LocalDate localdate = LocalDate.of(1979, 7, 27);
		System.out.println("私の誕生日は" + localdate.getYear() + "年" + localdate.getMonthValue() + "月"
				+ localdate.getDayOfMonth() + "日です。");
	}

}
