package com.example;

import java.time.LocalDateTime;

public class ExamBonusAnswer {

	public static void main(String[] args) {
		LocalDateTime localdatetime = LocalDateTime.of(1543, 2, 10, 5, 12);
		System.out.println("徳川家康の誕生日は" + localdatetime + "です。");
		localdatetime = localdatetime.plusYears(1);
		localdatetime = localdatetime.plusMonths(2);
		localdatetime = localdatetime.plusDays(3);
		localdatetime = localdatetime.plusHours(4);
		localdatetime = localdatetime.plusMinutes(5);
		System.out.println("1年2カ月3日4時間5分後は" + localdatetime + "です");

		System.out.println();
	}

}
