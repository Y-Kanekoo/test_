package com.example;

public class Exam2Answer {

	public static void main(String[] args) {
		String famoussSpeech = "Stay hungry,stay foolish.";
		System.out.println("hungryは" + famoussSpeech.indexOf("hungry") + "番目から始まります。");
	}

}
