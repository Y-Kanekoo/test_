package com.example;

import java.time.LocalDateTime;

public class Exam4Answer {

	public static void main(String[] args) {
		LocalDateTime localdate = LocalDateTime.now();
		System.out.println(localdate);
	}

}
