package exam1;

public class Exam1Answer {

	public static void main(String[] args) {
		CarAnswer car = new SuperCarAnswer();
		car.setName("フェラーリ");
		car.putOnGas();
		car.run();
		car = new EcoCarAnswer();
		car.setName("プリウス");
		car.putOnGas();
		car.run();
	}
}