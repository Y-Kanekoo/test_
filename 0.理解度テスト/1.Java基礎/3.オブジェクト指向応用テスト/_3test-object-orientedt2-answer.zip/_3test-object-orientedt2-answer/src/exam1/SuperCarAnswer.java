package exam1;

public class SuperCarAnswer extends CarAnswer {
	public void run() {
		System.out.println("ブオーン！" + name + "が走ります");
	}
}