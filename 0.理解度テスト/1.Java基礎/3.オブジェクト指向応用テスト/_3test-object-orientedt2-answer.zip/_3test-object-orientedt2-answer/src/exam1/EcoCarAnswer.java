package exam1;

public class EcoCarAnswer extends CarAnswer {
	public void run() {
		System.out.println("シーン！" + name + "が走ります");
	}
}