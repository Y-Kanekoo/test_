package exam2;

public class HorseAnswer implements AnimalAnswer {
	public void cry() {
		System.out.println("whinny");
	}
}
