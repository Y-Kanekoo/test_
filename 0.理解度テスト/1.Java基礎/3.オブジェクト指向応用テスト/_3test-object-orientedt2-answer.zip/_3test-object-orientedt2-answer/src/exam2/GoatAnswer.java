package exam2;

public class GoatAnswer implements AnimalAnswer {
	public void cry() {
		System.out.println("bleat");
	}
}
