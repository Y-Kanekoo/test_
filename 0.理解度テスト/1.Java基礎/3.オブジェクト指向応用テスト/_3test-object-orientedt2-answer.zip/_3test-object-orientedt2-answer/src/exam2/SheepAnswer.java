package exam2;

public class SheepAnswer implements AnimalAnswer {
	public void cry() {
		System.out.println("baa");
	}
}
