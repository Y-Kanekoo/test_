package exam2;

public interface AnimalAnswer {
	public void cry();
}
