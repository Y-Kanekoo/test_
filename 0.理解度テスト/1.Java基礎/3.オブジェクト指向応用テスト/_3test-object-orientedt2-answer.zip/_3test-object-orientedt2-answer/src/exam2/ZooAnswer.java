package exam2;

public class ZooAnswer {

	public static void main(String[] args) {

		AnimalAnswer[] animals = new AnimalAnswer[3];
		animals[0] = new SheepAnswer();
		animals[1] = new HorseAnswer();
		animals[2] = new GoatAnswer();

		// 通常のfor文
		for(int i = 0; i < animals.length; i++) {
			AnimalAnswer animal = animals[i];
			animal.cry();
		}

		// 拡張for文
		for (AnimalAnswer animal : animals) {
			animal.cry();
		}
	}

}
