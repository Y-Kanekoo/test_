package exambonus;

public interface TimeMachineAnswer {
	public void timeTravel();
}
