package exambonus;

public class DeLoreanAnswer implements AirplanAnswer, CarAnswer, TimeMachineAnswer {
	public void run() {
		System.out.println("デロリアンが走る！");
	}

	public void fly() {
		System.out.println("デロリアンが飛ぶ！");
	}

	public void timeTravel() {
		System.out.println("デロリアンがタイムテレポート！");
	}

	public void engineStart() {
		this.run();
		this.fly();
		this.timeTravel();
	}
}
