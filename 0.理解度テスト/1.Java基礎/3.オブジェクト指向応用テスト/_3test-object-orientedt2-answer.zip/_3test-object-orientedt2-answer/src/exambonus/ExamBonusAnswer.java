package exambonus;

public class ExamBonusAnswer {

	public static void main(String[] args) {
		DeLoreanAnswer delorean = new DeLoreanAnswer();
		delorean.engineStart();
	}

}
