package exambonus;

public interface CarAnswer {
	public void run();
}
