package exambonus;

public interface AirplanAnswer {
	public void fly();
}
