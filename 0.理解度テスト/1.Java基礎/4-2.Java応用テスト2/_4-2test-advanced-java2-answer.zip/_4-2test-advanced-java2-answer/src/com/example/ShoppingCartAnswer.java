package com.example;

import java.util.LinkedList;

public class ShoppingCartAnswer extends LinkedList<ItemAnswer> {

	private static final long serialVersionUID = 1L;

	public int getTotalPrice() {
		int total = 0;

		// 拡張for文
		for(ItemAnswer item : this) {
			total += item.getPrice();
		}
//		// 通常のfor文
//		for (int i = 0; i < this.size(); i++) {
//			total += this.get(i).getPrice();
//		}
		return total;
	}

	public int getAveragePrice() {
		int average = 0;

		average = getTotalPrice() / this.size();
		return average;
	}

}
