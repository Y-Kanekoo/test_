package com.example;

import java.util.ArrayList;
import java.util.List;

public class Exam3Answer {
	public static void main(String[] args) {

		List<EmployeeAnswer> list = new ArrayList<>();

		list.add(new EmployeeAnswer("伊賀", 31));
		list.add(new EmployeeAnswer("山田", 28));
		list.add(new EmployeeAnswer("佐藤", 25));
		list.add(new EmployeeAnswer("田中", 19));

		for (EmployeeAnswer employee : list) {
			System.out.println(employee.getName() + "(" + employee.getAge() + ")");
		}

	}
}
