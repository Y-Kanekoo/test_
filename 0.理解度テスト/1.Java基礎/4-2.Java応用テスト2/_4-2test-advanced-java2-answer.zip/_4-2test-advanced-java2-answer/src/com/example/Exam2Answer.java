package com.example;

import java.util.ArrayList;
import java.util.List;

public class Exam2Answer {
	public static void main(String[] args) {
		List<String> list = new ArrayList<>();

		list.add("伊賀");
		list.add("山田");
		list.add("佐藤");
		list.add("田中");

		list.remove(0);

		for (String name : list) {
			System.out.println(name);
		}

	}
}