package com.example;

public class ExsmBonusAnswer {
	public static void main(String[] args) {

		ItemAnswer item1 = new ItemAnswer("アナと雪の女王", 3000);
		ItemAnswer item2 = new ItemAnswer("美女と野獣", 2000);
		ItemAnswer item3 = new ItemAnswer("モアナと伝説の海", 8000);

		ShoppingCartAnswer shoppingCart = new ShoppingCartAnswer();

		shoppingCart.add(item1);
		shoppingCart.add(item2);
		shoppingCart.add(item3);

		System.out.println("合計：" + shoppingCart.getTotalPrice() + "円");
		System.out.println("平均：" + shoppingCart.getAveragePrice() + "円");

	}
}
