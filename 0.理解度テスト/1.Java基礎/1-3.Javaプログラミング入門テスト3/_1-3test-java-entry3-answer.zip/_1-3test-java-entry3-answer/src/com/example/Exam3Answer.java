package com.example;

public class Exam3Answer {

	public static void main(String[] args) {
		viewName(3);
	}

	static void viewName(int time) {
		for (int i = 1; i <= time; i++) {
			System.out.println("伊賀将之");
		}
	}
}
