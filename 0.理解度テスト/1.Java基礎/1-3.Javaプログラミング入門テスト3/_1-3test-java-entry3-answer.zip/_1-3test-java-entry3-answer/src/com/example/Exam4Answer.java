package com.example;

public class Exam4Answer {
	public static void main(String[] args) {
		System.out.println(getName());
	}
	
	static String getName(){
		return "伊賀将之";
	}

}
