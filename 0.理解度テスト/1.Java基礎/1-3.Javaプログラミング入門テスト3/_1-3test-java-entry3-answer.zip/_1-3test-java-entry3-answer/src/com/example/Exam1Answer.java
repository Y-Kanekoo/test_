package com.example;

public class Exam1Answer {

    public static void main(String[] args) {
        viewName();
    }

    static void viewName() {
        System.out.println("伊賀将之");
    }
}
