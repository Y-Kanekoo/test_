package com.example;

public class Exam2Answer {

	public static void main(String[] args) {
		viewNameFiveTimes();
	}

	static void viewNameFiveTimes() {
		for (int i = 1; i <= 5; i++) {
			System.out.println("伊賀将之");
		}
	}
}
