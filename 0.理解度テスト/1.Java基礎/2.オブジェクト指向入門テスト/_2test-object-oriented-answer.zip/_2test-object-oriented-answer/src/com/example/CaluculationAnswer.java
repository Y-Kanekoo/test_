package com.example;

public class CaluculationAnswer {
    public static int addition(int num1, int num2) {// 加算
        return num1 + num2;
    }

    public static int substraction(int num1, int num2) {// 減算
        return num1 - num2;
    }

    public static int multiplication(int num1, int num2) {// 乗算
        return num1 * num2;
    }

    public static int division(int num1, int num2) {// 除算
        return num1 / num2;
    }

    public static int remainder(int num1, int num2) {// 剰余
        return num1 % num2;
    }
}
