package com.example;

public class CarAnswer {
	int speed; // スピードフィールド

	public void run() { // 加速メソッド
		speed += 50;
		System.out.println("走りました。スピードが" + speed + "km/hになりました。");
		if (speed >= 120) {
			System.out.println("スピードの出しすぎです。");
		}
	}
}
