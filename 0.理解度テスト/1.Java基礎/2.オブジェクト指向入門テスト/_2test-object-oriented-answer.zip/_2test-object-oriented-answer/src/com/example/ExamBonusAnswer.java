package com.example;

public class ExamBonusAnswer {

	public static void main(String[] args) {
		System.out.println("足し算の結果:" + CaluculationAnswer.addition(5, 3));
		System.out.println("引き算の結果:" + CaluculationAnswer.substraction(5, 3));
		System.out.println("掛け算の結果:" + CaluculationAnswer.multiplication(5, 3));
		System.out.println("割り算の結果:" + CaluculationAnswer.division(5, 3));
		System.out.println("剰余の結果:" + CaluculationAnswer.remainder(5, 3));
	}

}
