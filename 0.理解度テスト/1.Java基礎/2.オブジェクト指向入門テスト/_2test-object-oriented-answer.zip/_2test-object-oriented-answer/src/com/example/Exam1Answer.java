package com.example;

public class Exam1Answer {

	public static void main(String[] args) {
		CarAnswer car = new CarAnswer();

		car.run();
		car.run();
		car.run();
	}

}
