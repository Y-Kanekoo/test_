package com.example;

public class Exam3Answer {

	public static void main(String[] args) {
		StudentAnswer student = new StudentAnswer();
		student.study();
		student.study();
		student.sleep();
		student.sleep();
	}

}
