package com.example;

public class Exam2Answer {

	public static void main(String[] args) {
		String day[] = { "月", "火", "水", "木", "金", "土", "日" };

		for (int i = 0; i < day.length; i++) {
			System.out.println(day[i]);
		}
	}

}
