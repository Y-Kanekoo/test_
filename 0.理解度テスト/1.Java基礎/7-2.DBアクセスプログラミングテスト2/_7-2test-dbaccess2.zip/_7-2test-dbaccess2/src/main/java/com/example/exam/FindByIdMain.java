package com.example.exam;

import com.example.dao.MemberDao;

/**
 * findById()メソッド、動作確認用の実行クラスです.
 * 
 * @author igamasayuki
 *
 */
public class FindByIdMain {

	public static void main(String[] args) {
		MemberDao dao = new MemberDao();

	}

}
