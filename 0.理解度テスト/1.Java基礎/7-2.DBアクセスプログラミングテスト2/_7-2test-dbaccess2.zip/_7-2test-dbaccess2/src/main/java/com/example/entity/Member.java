package com.example.entity;

/**
 * メンバー情報を表すエンティティ.
 * 
 * @author igamasayuki
 *
 */
public class Member {
	/** ID */
	
	/** 名前 */
	
	/** 年齢 */
	
	/** 部署ID */

}
