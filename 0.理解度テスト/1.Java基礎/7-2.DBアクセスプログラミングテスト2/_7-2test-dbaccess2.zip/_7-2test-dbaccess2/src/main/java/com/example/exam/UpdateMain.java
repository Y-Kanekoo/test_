package com.example.exam;

import com.example.dao.MemberDao;

/**
 * update()メソッド、動作確認用の実行クラスです.
 * 
 * @author igamasayuki
 *
 */
public class UpdateMain {
	public static void main(String[] args) {
		
		MemberDao dao = new MemberDao();

		
		System.out.println("update終了");
	}
}
