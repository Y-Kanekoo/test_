package com.example.exam;

import com.example.dao.MemberDaoAnswer;
import com.example.entity.MemberAnswer;

/**
 * update()メソッド、動作確認用の実行クラスです.
 * 
 * @author igamasayuki
 *
 */
public class UpdateMainAnswer {
	public static void main(String[] args) {

		MemberDaoAnswer dao = new MemberDaoAnswer();
		MemberAnswer member = dao.findById(2);
		member.setAge(100); // 100歳に変更(結果はpgAdminで確認する)
		dao.update(member);
		System.out.println("update終了");
	}
}
