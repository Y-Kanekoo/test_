package com.example.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.example.common.DBManager;
import com.example.entity.MemberAnswer;

/**
 * membersテーブルを操作するDao.
 * 
 * @author igamasayuki
 *
 */
public class MemberDaoAnswer {
	/**
	 * 全件検索を行います.
	 * 
	 * @return メンバー情報の全件
	 */
	public List<MemberAnswer> findAll(){
		Connection con = DBManager.createConnection();
		String sql = "select id,name,age,dep_id from test_members order by age DESC";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			// ここに全件検索処理を書く
			ResultSet rs = pstmt.executeQuery();
			
			List<MemberAnswer> memberList = new ArrayList<>();
			
			while(rs.next()){
				
				MemberAnswer member = new MemberAnswer();
				
				member.setId(rs.getInt("id"));
				member.setName(rs.getString("name"));
				member.setAge(rs.getInt("age"));
				member.setDepId(rs.getInt("dep_id"));
				
				memberList.add(member);
			}
			return memberList;
			
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("全件検索処理に失敗しました",e);
		} finally {
			DBManager.closeConnection(con);
		}
	}

	/**
	 * 主キー検索を行います.
	 * 
	 * @param id 検索したい主キーの値
	 * @return　メンバー情報(検索されなかった場合はnullが返ります)
	 */
	public MemberAnswer findById(int id){
		Connection con = DBManager.createConnection();
		String sql = "select id,name,age,dep_id from test_members where id = ?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			// ここに主キー検索処理を書く
			pstmt.setInt(1, id);
			
			ResultSet rs = pstmt.executeQuery();

			if(rs.next()){
				MemberAnswer member = new MemberAnswer();
				member.setId(rs.getInt("id"));
				member.setName(rs.getString("name"));
				member.setAge(rs.getInt("age"));
				member.setDepId(rs.getInt("dep_id"));
				return member; 
			}
			
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("主キー検索処理に失敗しました",e);
		} finally {
			DBManager.closeConnection(con);
		}
	}
	/**
	 * メンバー情報を登録します.
	 * 
	 * @param member メンバー情報
	 */
	public void insert(MemberAnswer member){
		Connection con = DBManager.createConnection();
		String sql = "INSERT INTO test_members (name , age , dep_id) values ( ? , ? , ? )";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			// ここに挿入処理を書く
			pstmt.setString(1, member.getName());
			pstmt.setInt(2, member.getAge());
			pstmt.setInt(3, member.getDepId());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("登録処理に失敗しました",e);
		} finally {
			DBManager.closeConnection(con);
		}
	}

	
	public void update(MemberAnswer member){
		Connection con = DBManager.createConnection();
		String sql = "update test_members set name = ? , age = ? , dep_id = ? where id = ?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, member.getName());
			pstmt.setInt(2, member.getAge());
			pstmt.setInt(3, member.getDepId());
			pstmt.setInt(4, member.getId());
			
			pstmt.executeUpdate();
		
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("登録処理に失敗しました",e);
		} finally {
			DBManager.closeConnection(con);
		}
	}
}
