package com.example.exam;

import com.example.dao.MemberDaoAnswer;
import com.example.entity.MemberAnswer;

/**
 * insert()メソッド、動作確認用の実行クラスです.
 * 
 * @author igamasayuki
 *
 */
public class InsertMainAnswer {

	public static void main(String[] args) {
		MemberDaoAnswer dao = new MemberDaoAnswer();

		MemberAnswer member = new MemberAnswer();
		member.setName("シロー");
		member.setAge(54);
		member.setDepId(3);
		dao.insert(member);

		System.out.println("insert終了");
	}

}
