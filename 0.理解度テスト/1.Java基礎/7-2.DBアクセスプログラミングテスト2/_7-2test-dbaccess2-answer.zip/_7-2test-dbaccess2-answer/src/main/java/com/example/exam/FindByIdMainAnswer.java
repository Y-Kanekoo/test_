package com.example.exam;

import com.example.dao.MemberDaoAnswer;
import com.example.entity.MemberAnswer;

/**
 * findById()メソッド、動作確認用の実行クラスです.
 * 
 * @author igamasayuki
 *
 */
public class FindByIdMainAnswer {

	public static void main(String[] args) {
		MemberDaoAnswer dao = new MemberDaoAnswer();

		MemberAnswer member = dao.findById(2);
		System.out.println("id = " + member.getId());
		System.out.println("name = " + member.getName());
		System.out.println("age = " + member.getAge());
		System.out.println("dep_id" + member.getDepId());

	}

}
