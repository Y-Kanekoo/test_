package com.example.exam;

import java.util.List;

import com.example.dao.MemberDaoAnswer;
import com.example.entity.MemberAnswer;

/**
 * findAll()メソッド、動作確認用の実行クラスです.
 * 
 * @author igamasayuki
 *
 */
public class FindAllMainAnswer {

	public static void main(String[] args) {
		MemberDaoAnswer dao = new MemberDaoAnswer();

		List<MemberAnswer> memberList = dao.findAll();

		for (MemberAnswer member : memberList) {
			System.out.println("id = " + member.getId());
			System.out.println("name = " + member.getName());
			System.out.println("age = " + member.getAge());
			System.out.println("dep_id" + member.getDepId());

			System.out.println("-------------------------");
			System.out.println();
		}

	}

}
