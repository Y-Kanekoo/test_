package com.example;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 * 雛形クラスです.<br>
 * これをコピーペーストして問題を解いて構いません。
 * 
 */
public class ExamBonusAnswer {
	public static void main(String[] args) {
		// 接続情報
		String url = "jdbc:postgresql://localhost:5432/student";
		String user = "postgres";
		String password = "postgres";
		

		Connection con = null; // 使用する変数の宣言
		PreparedStatement pstmt = null;
		String sql = null;
		ResultSet rs = null;

		try {
			// (1)データベースに接続
			con = DriverManager.getConnection(url, user, password);

			// (2)SQL文を作成
			sql = "SELECT tm.id AS tm_id, tm.name AS tm_name, age AS tm_age, td.name AS td_name FROM test_members tm JOIN test_deps td ON tm.dep_id = td.id ORDER BY tm.id;";

			// (3)SQL実行準備
			pstmt = con.prepareStatement(sql);

			// (4)SQL実行
			rs = pstmt.executeQuery();
			
			// (5)結果の操作
			while (rs.next()) {
				
				int id = rs.getInt("tm_id");
				String name = rs.getString("tm_name");
				int age = rs.getInt("tm_age");
				String dep_name = rs.getString("td_name");
				
				System.out.print("id="+ id + ",");
				System.out.print("name="+ name + ",");
				System.out.print("age="+ age + ",");
				System.out.print("dep_name="+ dep_name);
				System.out.println();
			}
			

		} catch (SQLException ex) {
			System.err.println("SQL = " + sql);
			ex.printStackTrace();
		} finally {
			// (6) 切断処理
			try {
				if (con != null) {
					con.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}

