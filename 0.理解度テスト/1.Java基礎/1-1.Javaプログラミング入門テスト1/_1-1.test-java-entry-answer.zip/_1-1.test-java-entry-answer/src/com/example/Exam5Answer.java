package com.example;

public class Exam5Answer {

	public static void main(String[] args) {
		
		System.out.println("1:boolean");
		System.out.println("2:char");
		System.out.println("3:byte");
		System.out.println("4:short");
		System.out.println("5:int");
		System.out.println("6:long");
		System.out.println("7:float");
		System.out.println("8:double");

	}

}