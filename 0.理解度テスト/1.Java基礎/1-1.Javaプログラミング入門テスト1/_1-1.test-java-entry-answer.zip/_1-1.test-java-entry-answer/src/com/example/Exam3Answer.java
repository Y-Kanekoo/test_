package com.example;

public class Exam3Answer {

	public static void main(String[] args) {

		int priceA = 200;
		int countA = 3;

		int priceB = 250;
		int countB = 4;

		// 消費税率
		double TAX_PERCENT = 0.1;
		// 小計
		int subTotal = (priceA * countA) + (priceB * countB);
		// 消費税
		int tax = (int) (subTotal * TAX_PERCENT);
		// 合計金額
		int total = subTotal + tax;

		System.out.println("小計\n" + subTotal + "円");
		System.out.println("消費税\n" + tax + "円");
		System.out.println("合計金額\n" + total + "円");

	}

}