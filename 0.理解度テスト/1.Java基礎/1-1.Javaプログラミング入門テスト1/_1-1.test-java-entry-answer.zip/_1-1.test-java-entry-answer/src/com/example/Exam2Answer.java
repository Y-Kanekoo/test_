package com.example;

public class Exam2Answer {

	public static void main(String[] args) {

		String name = "伊賀将之";
		System.out.println(name);
		System.out.println(name);
		System.out.println(name);

	}

}