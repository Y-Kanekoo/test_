package com.example;

public class Exam4Answer {

	public static void main(String[] args) {

		int answer = 0;

		double a = 3.3;
		double b = 5.5;

		answer = (int) (a * b);

		System.out.println("答えは" + answer + "です。");

	}

}