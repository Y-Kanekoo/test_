package com.example;

public class Exam1Answer {

	public static void main(String[] args) {

		System.out.println("伊賀将之");

	}

}