package com.example;

public class ExamBonusAnswer {

	public static void main(String[] args) {

		String statement = "Steve Jobs said\n\"Stay Hungry. Stay Foolish.\"";

		System.out.println(statement);

	}

}