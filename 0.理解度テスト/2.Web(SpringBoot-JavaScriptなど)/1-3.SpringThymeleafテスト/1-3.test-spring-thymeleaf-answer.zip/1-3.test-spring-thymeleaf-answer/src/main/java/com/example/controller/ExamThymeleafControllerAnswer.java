package com.example.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.domain.MemberAnswer;

@Controller
@RequestMapping("/ex-thymeleaf")
public class ExamThymeleafControllerAnswer {

	@GetMapping("")
	public String index() {
		return "ex-thymeleaf-input-answer";
	}

	@PostMapping("/register")
	public String register(String name, String age, String hobby1, String hobby2, String hobby3, Model model) {
		MemberAnswer member = new MemberAnswer();

		member.setName(name);

		member.setAge(Integer.parseInt(age));

		List<String> hobbyList = new ArrayList<>();
		hobbyList.add(hobby1);
		hobbyList.add(hobby2);
		hobbyList.add(hobby3);
		member.setHobbyList(hobbyList);

		model.addAttribute("member", member);

		return "ex-thymeleaf-result-answer";
	}

	// フォームクラスを使用した場合の解答例
//	@GetMapping("")
//	public String index(ExamThymeleafFormAnswer form) {
//		return "ex-thymeleaf-input-answer";
//	}
//	@PostMapping("/register")
//	public String register(ExamThymeleafFormAnswer form, Model model) {
//		MemberAnswer member = new MemberAnswer();
//		
//		member.setName(form.getName());
//		
//		member.setAge(Integer.parseInt(form.getAge()));
//		
//		List<String> hobbyList = new ArrayList<>();
//		hobbyList.add(form.getHobby1());
//		hobbyList.add(form.getHobby2());
//		hobbyList.add(form.getHobby3());
//		member.setHobbyList(hobbyList);
//		
//		model.addAttribute("member", member);
//		
//		return "ex-thymeleaf-result-answer";
//	}

}
