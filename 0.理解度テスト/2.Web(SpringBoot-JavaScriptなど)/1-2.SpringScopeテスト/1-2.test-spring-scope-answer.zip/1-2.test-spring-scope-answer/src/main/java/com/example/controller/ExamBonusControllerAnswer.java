package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.domain.UserAnswer;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/exam-bonus")
public class ExamBonusControllerAnswer {
	@Autowired
	private HttpSession session;

	@GetMapping("")
	public String index() {
		return "exam-bonus-input-answer";
	}

	@PostMapping("/login")
	public String login(String email, String password, Model model) {

		if ("yamada@sample.com".equals(email) && "yamayama".equals(password)) {

			UserAnswer user = new UserAnswer();
			user.setName("山田太郎");
			user.setEmail("yamada@sample.com");
			user.setAge(18);
			session.setAttribute("user", user);

			return "exam-bonus-result-answer";
		} else {

			model.addAttribute("message", "ログインに失敗しました");

			// ログイン失敗のため、ログイン画面に戻る
			return "exam-bonus-input-answer";
		}
	}

}
