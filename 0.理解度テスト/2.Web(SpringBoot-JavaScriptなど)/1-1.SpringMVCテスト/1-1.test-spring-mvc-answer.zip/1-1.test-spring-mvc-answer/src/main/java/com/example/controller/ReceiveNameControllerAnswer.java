package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.form.ReceiveNameFormAnswer;

@Controller
@RequestMapping("/receive-name")
public class ReceiveNameControllerAnswer {

//	@GetMapping("")
//	public String index() {
//		return "name-form-answer";
//	}
	
	@GetMapping("")
	public String index(ReceiveNameFormAnswer form) {
		return "name-form-answer";
	}

	@PostMapping("/receive1")
	public String receive1(String name) {
		System.out.println("入力された値は" + name + "です。");
		return "finished-answer";
	}
	
	@PostMapping("/receive2")
	public String receive2(ReceiveNameFormAnswer form) {
		System.out.println("入力された値は" + form.getName() + "です。");
		return "finished-answer";
	}
	
}
