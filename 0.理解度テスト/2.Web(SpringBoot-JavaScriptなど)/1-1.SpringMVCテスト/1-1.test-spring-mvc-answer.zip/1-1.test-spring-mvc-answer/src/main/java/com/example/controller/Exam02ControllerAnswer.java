package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/exam02")
public class Exam02ControllerAnswer {

	@GetMapping("/show-company-introduction")
	public String showCompanyIntroduction() {
		return "redirect:/exam02/show-company-introduction2";
	}

	@GetMapping("/show-company-introduction2")
	public String showCompanyIntroduction2() {
		return "exam-02-answer";
	}
}
