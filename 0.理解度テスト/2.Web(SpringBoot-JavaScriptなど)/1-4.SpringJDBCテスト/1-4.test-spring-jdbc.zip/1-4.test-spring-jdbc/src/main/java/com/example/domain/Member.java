package com.example.domain;

/**
 * メンバー情報を表すドメイン.
 * 
 * @author igamasayuki
 *
 */
public class Member {
	/** ID */
	
	/** 名前 */
	
	/** 年齢 */
	
	/** 部署ID */

}
