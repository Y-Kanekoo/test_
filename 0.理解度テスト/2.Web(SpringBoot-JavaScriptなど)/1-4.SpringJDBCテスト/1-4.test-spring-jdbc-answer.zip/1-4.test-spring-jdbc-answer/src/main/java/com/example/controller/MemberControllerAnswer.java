package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.domain.MemberAnswer;
import com.example.repository.MemberRepositoryAnswer;

@Controller
@RequestMapping("/member")
public class MemberControllerAnswer {
	@Autowired
	private MemberRepositoryAnswer repository;

	@GetMapping("")
	public String index() {
		
		repository.findAll().forEach(System.out::println);
		
		System.out.println("==================================");
		
		MemberAnswer member = repository.findById(2);
		System.out.println(member);
		
		System.out.println("==================================");
		System.out.println("ボーナス問題確認");
		
		// 登録
		MemberAnswer insertMember = new MemberAnswer();
		insertMember.setName("山田太郎");
		insertMember.setAge(30);
		insertMember.setDepId(1);
		repository.save(insertMember);
		
		// 更新
		member.setName("シロー");
		repository.save(member);
		
		return "member";
	}
}
